<?php
require_once '../../../app/helpers/auth_helper.php';
requireAdmin();
require_once '../../../app/config/database.php';

if (!isset($_GET['id'])) {
    die("Employee ID missing.");
}

$employee_id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$employee_id]);
$emp = $stmt->fetch();

if (!$emp) {
    die("Employee not found.");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>

<div class="container mt-4">
    <a href="list.php" class="btn btn-secondary btn-sm mb-3">← Back to List</a>

    <h2>Employee Details</h2>
    <hr>

    <div class="row">

        <div class="col-md-6">
            <h4>Personal Information</h4>
            <table class="table table-bordered">
                <tr><th>Employee Code</th><td><?= $emp['employee_code'] ?></td></tr>
                <tr><th>Name</th><td><?= $emp['first_name'] . " " . $emp['last_name'] ?></td></tr>
                <tr><th>Email</th><td><?= $emp['email'] ?></td></tr>
                <tr><th>Phone</th><td><?= $emp['phone'] ?></td></tr>
                <tr><th>DOB</th><td><?= $emp['dob'] ?></td></tr>
                <tr><th>Gender</th><td><?= ucfirst($emp['gender']) ?></td></tr>
                <tr><th>Address</th><td><?= $emp['address'] ?></td></tr>
                <tr><th>City</th><td><?= $emp['city'] ?></td></tr>
                <tr><th>State</th><td><?= $emp['state'] ?></td></tr>
                <tr><th>Pincode</th><td><?= $emp['pincode'] ?></td></tr>
            </table>
        </div>

        <div class="col-md-6">
            <h4>Job Information</h4>
            <table class="table table-bordered">
                <tr><th>Department</th><td><?= $emp['department'] ?></td></tr>
                <tr><th>Designation</th><td><?= $emp['designation'] ?></td></tr>
                <tr><th>Reporting Manager</th>
                    <td>
                        <?php
                        if ($emp['reporting_manager']) {
                            $mgr = $pdo->query("SELECT first_name, last_name FROM employees WHERE id={$emp['reporting_manager']}")->fetch();
                            echo $mgr['first_name'] . " " . $mgr['last_name'];
                        } else {
                            echo "N/A";
                        }
                        ?>
                    </td>
                </tr>
                <tr><th>Joining Date</th><td><?= $emp['joining_date'] ?></td></tr>
                <tr><th>Status</th><td><?= ucfirst($emp['status']) ?></td></tr>
            </table>
        </div>
    </div>

    <h4 class="mt-4">Documents</h4>
    <table class="table table-bordered" style="max-width:500px;">
        <tr>
            <th>Resume</th>
            <td>
                <?php if ($emp['resume']) { ?>
                <a href="../../assets/uploads/employee_docs/<?= $employee_id ?>/<?= $emp['resume'] ?>" target="_blank">View</a>
                <?php } else { echo "Not Uploaded"; } ?>
            </td>
        </tr>

        <tr>
            <th>Aadhar</th>
            <td>
                <?php if ($emp['aadhar']) { ?>
                <a href="../../assets/uploads/employee_docs/<?= $employee_id ?>/<?= $emp['aadhar'] ?>" target="_blank">View</a>
                <?php } else { echo "Not Uploaded"; } ?>
            </td>
        </tr>

        <tr>
            <th>PAN</th>
            <td>
                <?php if ($emp['pan']) { ?>
                <a href="../../assets/uploads/employee_docs/<?= $employee_id ?>/<?= $emp['pan'] ?>" target="_blank">View</a>
                <?php } else { echo "Not Uploaded"; } ?>
            </td>
        </tr>
    </table>

    <a href="edit.php?id=<?= $employee_id ?>" class="btn btn-primary">Edit Employee</a>

</div>

</body>
</html>
