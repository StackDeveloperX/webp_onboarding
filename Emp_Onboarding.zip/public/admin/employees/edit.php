<?php
require_once '../../../app/helpers/auth_helper.php';
requireAdmin();
require_once '../../../app/config/database.php';

if (!isset($_GET['id'])) { die("Employee ID missing."); }

$employee_id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$employee_id]);
$emp = $stmt->fetch();

if (!$emp) { die("Employee not found."); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>

<div class="container mt-4">
    <a href="list.php" class="btn btn-secondary btn-sm mb-3">← Back</a>

    <h2>Edit Employee</h2>
    <hr>

    <div id="alert-box"></div>

    <form id="editEmployeeForm" enctype="multipart/form-data">
        <input type="hidden" name="employee_id" value="<?= $employee_id ?>">

        <div class="row">

            <h4 class="mb-3 mt-3">Personal Information</h4>

            <div class="col-md-4 mb-3">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control" value="<?= $emp['first_name'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control" value="<?= $emp['last_name'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" value="<?= $emp['email'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Phone</label>
                <input type="text" name="phone" class="form-control" value="<?= $emp['phone'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>DOB</label>
                <input type="date" name="dob" class="form-control" value="<?= $emp['dob'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Gender</label>
                <select name="gender" class="form-control">
                    <option <?= $emp['gender']=='male'?'selected':'' ?>>male</option>
                    <option <?= $emp['gender']=='female'?'selected':'' ?>>female</option>
                    <option <?= $emp['gender']=='other'?'selected':'' ?>>other</option>
                </select>
            </div>

            <div class="col-md-12 mb-3">
                <label>Address</label>
                <textarea name="address" class="form-control"><?= $emp['address'] ?></textarea>
            </div>

            <div class="col-md-4 mb-3">
                <label>City</label>
                <input type="text" name="city" class="form-control" value="<?= $emp['city'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>State</label>
                <input type="text" name="state" class="form-control" value="<?= $emp['state'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Pincode</label>
                <input type="text" name="pincode" class="form-control" value="<?= $emp['pincode'] ?>">
            </div>


            <h4 class="mt-5 mb-3">Job Information</h4>

            <div class="col-md-4 mb-3">
                <label>Department</label>
                <input type="text" name="department" class="form-control" value="<?= $emp['department'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Designation</label>
                <input type="text" name="designation" class="form-control" value="<?= $emp['designation'] ?>">
            </div>

            <div class="col-md-4 mb-3">
                <label>Reporting Manager</label>
                <select name="reporting_manager" class="form-control">
                    <option value="">Select</option>
                    <?php
                    $mgr = $pdo->query("SELECT id, first_name, last_name FROM employees WHERE status='active'");
                    while($m=$mgr->fetch()):
                    ?>
                    <option value="<?= $m['id'] ?>" <?= $emp['reporting_manager']==$m['id']?'selected':'' ?>>
                        <?= $m['first_name'].' '.$m['last_name'] ?>
                    </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="col-md-4 mb-3">
                <label>Joining Date</label>
                <input type="date" name="joining_date" class="form-control" value="<?= $emp['joining_date'] ?>">
            </div>



            <h4 class="mt-5 mb-3">Documents</h4>

            <div class="col-md-4 mb-3">
                <label>Resume</label>
                <input type="file" name="resume" class="form-control">
                <?php if($emp['resume']){ ?>
                <small>Current: <?= $emp['resume'] ?></small>
                <?php } ?>
            </div>

            <div class="col-md-4 mb-3">
                <label>Aadhar</label>
                <input type="file" name="aadhar" class="form-control">
                <?php if($emp['aadhar']){ ?>
                <small>Current: <?= $emp['aadhar'] ?></small>
                <?php } ?>
            </div>

            <div class="col-md-4 mb-3">
                <label>PAN</label>
                <input type="file" name="pan" class="form-control">
                <?php if($emp['pan']){ ?>
                <small>Current: <?= $emp['pan'] ?></small>
                <?php } ?>
            </div>

        </div>

        <button type="submit" class="btn btn-success">Update Employee</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
$("#editEmployeeForm").on("submit", function(e){
    e.preventDefault();

    let formData = new FormData(this);

    $.ajax({
        url: "../../ajax/employee_edit_ajax.php",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        dataType: "json",
        success: (res) => {
            $("#alert-box").html(`<div class="alert alert-${res.status}">${res.message}</div>`);
        }
    });
});
</script>

</body>
</html>
